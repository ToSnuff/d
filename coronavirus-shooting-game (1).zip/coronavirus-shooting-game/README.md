# Coronavirus Shooting Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/faisal-jawed/pen/NWqeRNZ](https://codepen.io/faisal-jawed/pen/NWqeRNZ).

This is a Shooting game where we shoot some coronaviruses!